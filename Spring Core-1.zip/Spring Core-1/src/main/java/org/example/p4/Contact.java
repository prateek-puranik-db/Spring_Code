package org.example.p4;

public class Contact
{
    String city;
    String mob;
    String email;
    public Contact()
    { }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getMob() {
        return mob;
    }
    public void setMob(String mob) {
        this.mob = mob;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    @Override
    public String toString() {
        return "Contact Details " + city +"  "+ mob +" "+ email ;
    }
}
