package org.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class App
{
    public static void main( String[] args )
    {
        ApplicationContext apctx=
                new AnnotationConfigApplicationContext(EmpConfig.class);
        Emp eobj1= (Emp) apctx.getBean("eobj1");
        System.out.println(eobj1);
        Emp eobj2= (Emp) apctx.getBean("eobj2");
        System.out.println(eobj2);
        Emp eobj3= (Emp) apctx.getBean("eobj3");
        System.out.println(eobj3);
        ((AbstractApplicationContext) apctx).close();
    }
}
