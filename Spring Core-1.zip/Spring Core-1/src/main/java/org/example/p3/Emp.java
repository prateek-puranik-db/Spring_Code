package org.example.p3;

import org.springframework.beans.factory.annotation.Autowired;

public class Emp
{
    int id;
    String ename;

    @Autowired // autowiring by name
    Address aobj;  // name of the object is carried thru out the project

    public Emp()
    {}

    public Emp(int id, String ename)
    {
        this.id = id;
        this.ename = ename;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getEname() {
        return ename;
    }
    public void setEname(String ename) {
        this.ename = ename;
    }
    /*
     * public Address getAobj() { return aobj; }
     *
     * public void setAobj(Address aobj) { this.aobj = aobj; }
     */

    @Override
    public String toString() {
        return "Id=" + id + ",  Name=" + ename + ", Address=" + aobj ;
    }
}

