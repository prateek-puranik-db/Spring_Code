package org.example.p2;

import java.util.LinkedList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EmpCfg
{
    @Bean(name="elist1")
    public EmpList  getEmpList()
    {
        LinkedList<Emp> emplist= new LinkedList<Emp>();
        emplist.add(new Emp(101, "Bulbul", 25000.00));
        emplist.add(new Emp(102, "Riaz", 35000.00));
        emplist.add(new Emp(103, "John", 65000.00));
        emplist.add(new Emp(104, "Manisha", 15000.00));
        emplist.add(new Emp(105, "Laxmi", 35000.00));
        EmpList elist1= new EmpList(emplist);
        return elist1;
    }

    @Bean(name="elist2")
    public EmpList  retEmpList()
    {
        EmpList elist2= new EmpList();
        LinkedList<Emp> emplist= new LinkedList<Emp>();
        emplist.add(new Emp(201, "Chandra", 55000.00));
        emplist.add(new Emp(202, "Dany", 25000.00));
        emplist.add(new Emp(203, "Abraham", 35000.00));
        emplist.add(new Emp(204, "Koirala", 25000.00));
        emplist.add(new Emp(205, "Padma", 25000.00));
        elist2.setEmplist(emplist);
        return elist2;
    }
}


