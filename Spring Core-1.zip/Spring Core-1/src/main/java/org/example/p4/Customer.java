package org.example.p4;

import org.springframework.beans.factory.annotation.Autowired;

public class Customer
{
    int  id;
    String cname;

    @Autowired
    Account acc_details;

    @Autowired
    Contact c_details;

    @Autowired
    Address addr;

    public  Customer()
    { }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getCname() {
        return cname;
    }
    public void setCname(String cname) {
        this.cname = cname;
    }

    /*
     * public Account getAcc_details() { return acc_details; } public void
     * setAcc_details(Account acc_details) { this.acc_details = acc_details; }
     * public Contact getC_details() { return c_details; } public void
     * setC_details(Contact c_details) { this.c_details = c_details; }
     */
    @Override
    public String toString() {
        return "Customer Details " + id +"  " + cname + " " + acc_details + " " + c_details ;
    }

}

