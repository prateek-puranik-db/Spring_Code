package org.example;


import java.util.Scanner;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EmpConfig
{
    @Bean(name="eobj1")
    public Emp constEmp()
    {
        Emp eobj1= new Emp(1001, "Jay", 25000.00);
        return eobj1;
    }

    @Bean(name="eobj2")
    public Emp setEmp()
    {
        Emp eobj2= new Emp();
        eobj2.setId(2002);
        eobj2.setEname("Ajay");
        eobj2.setEsal(30000.00);
        return eobj2;
    }

    @Bean(name="eobj3")
    public Emp inputEmp()
    {
        Emp eobj3= new Emp();
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter the Employee id, name and salary");
        eobj3.setId( sc.nextInt());
        eobj3.setEname(sc.next());
        eobj3.setEsal(sc.nextDouble());
        sc.close();
        return eobj3;
    }
}


