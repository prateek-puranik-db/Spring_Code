package org.example.p3;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EmpCfg
{
    @Bean   //(name=" ")
    public Address getAddr()
    {
        Address aobj1= new Address();
        aobj1.setHno(101); // aobj1.setHno(Scanner
        aobj1.setLocality("Andheri");
        aobj1.setCity("Mumbai");
        return aobj1;
    }

   /*@Bean
	public Address getAddr1()
	{
		Address aobj2= new Address();
		aobj2.setHno(102);
		aobj2.setLocality("Kurla");
		aobj2.setCity("Mumbai");
		return aobj2;
	}*/

    @Bean(name="empobj1")
    public Emp getEmp()
    {
        Emp empobj1= new Emp(1001, "Vijay");
        return empobj1;
    }

    @Bean(name="empobj2")
    public Emp setEmp()
    {
        Emp empobj2= new Emp();
        empobj2.setId(2002);
        empobj2.setEname("Vicky");
        return empobj2;
    }
}



