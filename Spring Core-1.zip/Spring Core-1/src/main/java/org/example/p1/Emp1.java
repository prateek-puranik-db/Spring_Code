package org.example.p1;

public class Emp1
{
    int id;
    String ename;
    public Emp1()
    { }
    public Emp1(int id, String ename)
    {
        this.id = id;
        this.ename = ename;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getEname() {
        return ename;
    }
    public void setEname(String ename) {
        this.ename = ename;
    }

}

