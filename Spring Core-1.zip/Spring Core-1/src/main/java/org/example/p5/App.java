package org.example.p5;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App
{
    public static void main(String args[])
    {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("Beans1.xml");
        EmployeeJdbcTemplate employeeJdbcTemplate =
                (EmployeeJdbcTemplate)context.getBean("employeeJdbcTemplate");

        // Display current state of Employee table
        List<Employee> emp = employeeJdbcTemplate.getAllEmployees();
        System.out.println("Current State of employee table -");
        System.out.println(emp);

        // insert new employee
        employeeJdbcTemplate.insertEmployee(5046, "Kapil", 60, 250000);

        // Display inserted employee
        Employee insertedEmployee = employeeJdbcTemplate.getEmployeeById(5046);
        System.out.println("Inserted Employee Information from Employee Table - ");
        System.out.println(insertedEmployee);

        // update employee
        Employee updatedEmployee = employeeJdbcTemplate.updateEmployee("Prabhu", 3);
        System.out.println("Updated Employee Information from Employee Table - ");
        System.out.println(updatedEmployee);

        //delete employee
        employeeJdbcTemplate.deleteEmployee(2);

        // display total number of employees
        // int count = employeeJdbcTemplate.getTotalNumberOfEmployees();
        System.out.println("Total number of Employees in employee table ");
        //System.out.println(count);

        emp = employeeJdbcTemplate.getAllEmployees();
        System.out.println("Current State of employee table -");
        System.out.println(emp);
        ((AbstractApplicationContext) context).close();
    }
}


