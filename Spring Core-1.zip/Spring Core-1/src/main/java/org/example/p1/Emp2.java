package org.example.p1;

public class Emp2 extends Emp1
{
    String  month;
    double amt;
    public Emp2()
    {super(); }

    public Emp2(int id, String ename, String month, double amt)
    {
        super(id, ename);
        this.month = month;
        this.amt = amt;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public double getAmt() {
        return amt;
    }

    public void setAmt(double amt) {
        this.amt = amt;
    }

    @Override
    public String toString() {
        return "Id="+getId()+", "+"Name="+getEname()+", "+"Month=" + getMonth() + ", Amount=" + getAmt() ;
    }

}





