package org.example.p1;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class App
{
    public static void main( String[] args )
    {
        ApplicationContext apctx= new AnnotationConfigApplicationContext(EmpConfig.class);
        Emp2 eobj1= (Emp2) apctx.getBean("eobj1");
        System.out.println(eobj1);
        Emp2 eobj2= (Emp2) apctx.getBean("eobj2");
        System.out.println(eobj2);
        ((AbstractApplicationContext) apctx).close();
    }
}
